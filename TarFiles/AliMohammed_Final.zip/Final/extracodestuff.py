# Extra code I wrote for testing purposes to figure things out


# def main():
#     e = Emitter(0)

#     e.print('cout << "brooo1" << endl; ')
#     with e.indent():
#         e.print('cout << "brooo2" << endl; ')
#         e.print('cout << "brooo3" << endl; ')
#         e.print('cout << "brooo4" << endl; ')
#         with e.indent():
#             e.print('cout << "brooo2" << endl; ')
#             e.print('cout << "brooo3" << endl; ')
#             e.print('cout << "brooo4" << endl; ')
#     e.print('cout << "hereeeeeeeeee" << endl; ')
            
    

# if __name__ == "__main__":
#     main()
